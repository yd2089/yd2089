package HW1;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Admin extends User implements interfaceAdmin{

	private static final long serialVersionUID = 1L;

	public Admin(String userName, String password, String firstName, String lastName) {
		super(userName,password, firstName, lastName);
		
	}

	@Override
	public void createCourse(Course course, ArrayList<Course> courseArray) {
		courseArray.add(course);
		System.out.println("The new course named "+course.getCourseName()+" has been created!");
	}

	@Override
	public void DeleteCourse(Course course, ArrayList<Course> courseArray) {		
//		for (int i=0;i<courseArray.size();i++) {
//			if (courseArray.get(i).getCourseName()==course.getCourseName()&&courseArray.get(i).getSectionNumber()==course.getSectionNumber()) {
		courseArray.remove(course);
		System.out.println("The course named "+course.getCourseName()+" has been removed!");
	}

	@Override
	public void editCourse(Course course, ArrayList<Course> courseArray){
		Scanner s = new Scanner (System.in);
		System.out.println("Which information on the course except for course ID and name you want to edit? Please enter the number\n"
				+ "1. maximum number of students \n"
				+ "2. current number of registered students \n"
				+ "3. list of names of students being registered in the given course \n"
				+ "4. course instructor \n"
				+ "5. course section number \n"
				+ "6. course location");
		String choice=s.nextLine();
		if (choice.equals("1")){
			System.out.println("What is the new maximum number of students?");	
			int max=Integer.parseInt(s.nextLine());
//			int count=0;
			for (int i=0;i<courseArray.size();i++) {
				if (courseArray.get(i)==course) {
					courseArray.get(i).setMaxStudent(max);
//					count=0;
//					break;
				}
//				else {
//					count=1;
//				}
			}
//			if (count!=0) {
//				System.out.println("Error!");
//			}
			System.out.println("The new maximum number of students is "+max);
		}
		else if (choice.equals("2")) {
			System.out.println("What is the current number of registered students?");
			int reg=Integer.parseInt(s.nextLine());
			for (int i=0;i<courseArray.size();i++) {
				if (courseArray.get(i)==course) {
					courseArray.get(i).setCurrentStudent(reg);;
				}
			}
			System.out.println("The new current number of registered students is "+reg);
		}
		else if (choice.equals("3")) {
			System.out.println("What is the new list of names of students being registered in the give course? Please enter in the form of name1, name2, name3,....");	
			String []namelist=s.nextLine().split(",");		
			List<String> NL= Arrays.asList(namelist);
			for (int i=0;i<courseArray.size();i++) {
				if (courseArray.get(i)==course) {
					courseArray.get(i).setStudentName(new ArrayList<String>(NL));
				}
			}
			System.out.println("The new list of names of students being registered in the give course has been set.");
		}
		else if (choice.equals("4")) {
			System.out.println("What is the new course instructor?");
			String instructor=s.nextLine();
			for (int i=0;i<courseArray.size();i++) {
				if (courseArray.get(i)==course) {
					courseArray.get(i).setInstructorName(instructor);
				}
			}
			System.out.println("The new instructor's name is: " +instructor);
		}
		else if (choice.equals("5")) {
			System.out.println("What is the new course section number?");
			Integer secNum=Integer.parseInt(s.nextLine());
			for (int i=0;i<courseArray.size();i++) {
				if (courseArray.get(i)==course) {
					courseArray.get(i).setSectionNumber(secNum);
				}
			}
			System.out.println("The new section number is: " +secNum);
			}
		else if (choice.equals("6")) {
			System.out.println("What is the new course location?");
			String loc=s.nextLine();
			for (int i=0;i<courseArray.size();i++) {
				if (courseArray.get(i)==course) {
					courseArray.get(i).setLocation(loc);
				}
			}
			System.out.println("The new location is: " +loc);
		}
		else {
			System.out.println("Cannot find what you want to edit. Please retry.");
		}
	}


	@Override
	public void displayGivenCourse(String courseName, Integer sectionNumber,ArrayList<Course> courseArray) {
		for(int i=0;i<courseArray.size();i++) {
			if (sectionNumber.equals(courseArray.get(i).getSectionNumber())&&courseName.equals(courseArray.get(i).getCourseName())) {
				System.out.print("Course Name: "+courseArray.get(i).getCourseName()+"\n"
						+"Course ID: "+courseArray.get(i).getCourseID()+"\n"
						+"Section Number: "+courseArray.get(i).getSectionNumber()+"\n"
						+"Max Student: "+courseArray.get(i).getMaxStudent()+"\n"
						+"Current Student: "+courseArray.get(i).getCurrentStudent()+"\n"
						+"List of Names: "+courseArray.get(i).getStudentName()+"\n"
						+"Course Instructors: "+courseArray.get(i).getInstructorName()+"\n"
						+"Course Location: "+courseArray.get(i).getLocation()+"\n");
			}
		}	
	}


	@Override
	public void registerStudent(String userName, String password, String firstName, String lastName, String courseName, Integer sectionNumber, ArrayList<Course> courseArray) {
		Integer coursefound=0;
		for(int i=0;i<courseArray.size();i++) {
			if (courseArray.get(i).getSectionNumber().equals(sectionNumber) && courseArray.get(i).getCourseName().equals(courseName)) {
				coursefound = 1;
					List<String> studentNames=new ArrayList<String>();
					System.out.println("number of students: "+allStudent.size());
					for( Student student : allStudent) {
						String fullname = student.getFirstName()+' '+student.getLastName();
						System.out.println("student: "+fullname);
						studentNames.add(fullname);
					}
					Integer ind = studentNames.indexOf(firstName+" "+lastName);
					// add course to student
					allStudent.get(ind).addCourse(courseName);
					// add student to course
					List<String> NSN=courseArray.get(i).getStudentName();
					NSN.add(firstName+" "+lastName);
					courseArray.get(i).setStudentName((ArrayList<String>)NSN);
					int cn=courseArray.get(i).getCurrentStudent();
					courseArray.get(i).setCurrentStudent(cn+1);
					break;
			}
		}
		if(coursefound==1) {
			System.out.println("You have registered "+ courseName+".");
		}
		else {
			System.out.println("The course does not exist!");	
		}
	}

	@Override
	public void Exit() {
		System.out.println("You have been log out!");
	}
	
	public void viewStudentCourse(String firstName, String lastName) {
		List<String> studentNames=new ArrayList<String>();
		for( Student student : allStudent) {
			String fullname = student.getFirstName()+" "+student.getLastName();
			studentNames.add(fullname);
		}
		Integer ind = studentNames.indexOf(firstName+" "+lastName);
		List<String> courses = allStudent.get(ind).getCourses();
		System.out.println(courses.size()+" courses for "+ firstName +" "+lastName+":");
		for (String course:courses) {
			System.out.println(course);
		}
	}


}
