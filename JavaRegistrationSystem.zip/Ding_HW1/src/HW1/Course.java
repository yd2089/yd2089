package HW1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Course implements Serializable{
	private static final long serialVersionUID = 1L;
	private String courseName;
	private String courseID;
	private Integer maxStudent;
	private Integer currentStudent;
	private List<String> studentName=new ArrayList<String>();
	private String instructorName;
	private Integer sectionNumber;
	private String location;
	
	public Course(String courseName, String courseID, Integer maxStudent, Integer currentStudent, String instructorName, Integer sectionNumber, String location) {
		super();
		this.courseName = courseName;
		this.courseID = courseID;
		this.maxStudent = maxStudent;
		this.currentStudent = currentStudent;
		this.instructorName = instructorName;
		this.sectionNumber = sectionNumber;
		this.location = location;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	public Integer getMaxStudent() {
		return maxStudent;
	}

	public void setMaxStudent(Integer maxStudent) {
		this.maxStudent = maxStudent;
	}

	public Integer getCurrentStudent() {
		return currentStudent;
	}

	public void setCurrentStudent(Integer currentStudent) {
		this.currentStudent = currentStudent;
	}

	public List<String> getStudentName() {
		return studentName;
	}

	public void setStudentName(ArrayList<String> nL) {
		this.studentName = nL;
	}

	public String getInstructorName() {
		return instructorName;
	}

	public void setInstructorName(String instructorName) {
		this.instructorName = instructorName;
	}

	public Integer getSectionNumber() {
		return sectionNumber;
	}

	public void setSectionNumber(Integer sectionNumber) {
		this.sectionNumber = sectionNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
