package HW1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable{
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	protected static List<String> studentName=new ArrayList<String>();
	protected static ArrayList<Student> allStudent=new ArrayList<Student>();
	
	public User(String userName, String password, String firstName, String lastName) {
		super();
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public List<String> getStudentName() {
		return studentName;
	}

	public void setStudentName(ArrayList<String> studentName) {
		User.studentName = studentName;
	}

	public ArrayList<Student> getAllStudent() {
		return allStudent;
	}

	public void setAllStudent(ArrayList<Student> allStudent) {
		User.allStudent = allStudent;
	}
	
}