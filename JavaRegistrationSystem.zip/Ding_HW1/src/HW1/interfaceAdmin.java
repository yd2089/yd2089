package HW1;

import java.util.ArrayList;

public interface interfaceAdmin {
	
	public void createCourse(Course course, ArrayList<Course> courseArray);
	public void DeleteCourse(Course course, ArrayList<Course> courseArray);
	public void editCourse(Course course, ArrayList<Course> courseArray);
	public void displayGivenCourse(String courseName,Integer sectionNumber,ArrayList<Course> courseArray);
	public void registerStudent(String userName, String password, String firstName, String lastName, String courseName, Integer sectionNumber,ArrayList<Course> courseArray);
	public void Exit();

}
