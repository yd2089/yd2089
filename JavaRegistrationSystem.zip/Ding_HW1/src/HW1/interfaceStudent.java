package HW1;

import java.util.ArrayList;

public interface interfaceStudent {
	
	public void viewAllCourses(ArrayList<Course> courseArray);
	public void viewNotFullCourses(ArrayList<Course> courseArray);
	public void registerCourse(String courseName, Integer sectionNumber, String studentName,ArrayList<Course> courseArray);
	public void withdrawCourse(String studentName, String courseName, ArrayList<Course> courseArray,Integer sectionNumber);
	public void viewStudentCourse(String firstName, String lastName);
	public void exit();
}
