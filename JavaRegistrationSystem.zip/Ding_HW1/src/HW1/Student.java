package HW1;

import java.util.ArrayList;
import java.util.List;

public class Student extends User implements interfaceStudent{
	
	private List<String> courses;
	private static final long serialVersionUID = 1L;

	public Student(String userName, String password, String firstName, String lastName,List<String> thecourses) {
		super(userName, password, firstName, lastName);
		this.courses=thecourses;
	}


	public List<String> getCourses() {
		return courses;
	}


	public void setCourses(List<String> courses) {
		this.courses = courses;
	}


	public void addCourse(String courseName) {
		this.courses.add(courseName);
	}
	
	public void removeCourse(String courseName) {
		this.courses.remove(courseName);
	}

	@Override
	public void viewAllCourses(ArrayList<Course> courseArray) {
		System.out.println("Here are all the courses: ");
		for(int i=0;i<courseArray.size();i++) {
			System.out.print("Course ID"+courseArray.get(i).getCourseID()+"\n"
						+"Course Name: "+courseArray.get(i).getCourseName()+"\n"
						+"List of Names: "+courseArray.get(i).getStudentName()+"\n"
						+"Max Student: "+courseArray.get(i).getMaxStudent()+"\n"
						+"Current Student: "+courseArray.get(i).getCurrentStudent()+"\n"
						+"Course Instructors: "+courseArray.get(i).getInstructorName()+"\n"
						+"Course Location: "+courseArray.get(i).getLocation()+"\n");
		}
	}

	@Override
	public void viewNotFullCourses(ArrayList<Course> courseArray) {
		System.out.println("Here are all the not full courses: ");
		for(int i=0;i<courseArray.size();i++) {
			if (courseArray.get(i).getCurrentStudent()<courseArray.get(i).getMaxStudent()) {
				System.out.print(courseArray.get(i).getCourseName()+ "\n");
			}
		}
	}


	@Override
	public void registerCourse(String courseName, Integer sectionNumber, String studentName, ArrayList<Course> courseArray) {
		Integer coursefound=0;
		for(int i=0;i<courseArray.size();i++) {
			if (courseArray.get(i).getSectionNumber().equals(sectionNumber) && courseArray.get(i).getCourseName().equals(courseName)) {
				coursefound = 1;
				if(courseArray.get(i).getCurrentStudent()<courseArray.get(i).getMaxStudent()) {
					List<String> studentNames=new ArrayList<String>();
					System.out.println("number of students: "+allStudent.size());
					for( Student student : allStudent) {
						String fullname = student.getFirstName()+' '+student.getLastName();
						System.out.println("student: "+fullname);
						studentNames.add(fullname);
					}
					Integer ind = studentNames.indexOf(studentName);
					// add course to student
					allStudent.get(ind).addCourse(courseName);
					// add student to course
					List<String> NSN=courseArray.get(i).getStudentName();
					NSN.add(studentName);
					courseArray.get(i).setStudentName((ArrayList<String>)NSN);
					int cn=courseArray.get(i).getCurrentStudent();
					courseArray.get(i).setCurrentStudent(cn+1);
					break;
						 //}	
				}
				 else {
					System.out.println("This class has already been full.");
				 }
			}
		}
		if(coursefound==1) {
			System.out.println("You have registered "+ courseName+".");
		}
		else {
			System.out.println("The course does not exist!");	
		}
		
	}


	@Override
	public void withdrawCourse(String studentName, String courseName, ArrayList<Course> courseArray, Integer sectionNumber) {
		Integer coursefound=0;
		for(int i=0;i<courseArray.size();i++) {
			if (courseArray.get(i).getSectionNumber().equals(sectionNumber) && courseArray.get(i).getCourseName().equals(courseName)) {
			
				coursefound = 1;			
				List<String> studentNames=new ArrayList<String>();
				System.out.println("number of students: "+allStudent.size());
				
				for( Student student : allStudent) {
					String fullname = student.getFirstName()+' '+student.getLastName();
					System.out.println("student: "+fullname);
					studentNames.add(fullname);
				}
				
				Integer ind = studentNames.indexOf(studentName);
				allStudent.get(ind).removeCourse(courseName);
				List<String> NSN=courseArray.get(i).getStudentName();
				courseArray.get(i).setStudentName((ArrayList<String>)NSN);
				int cn=courseArray.get(i).getCurrentStudent();
				courseArray.get(i).setCurrentStudent(cn-1);
				NSN.remove(studentName);
						
				break;
						 
			}
		}
		if(coursefound==1) {
			System.out.println("You have removed "+ courseName+".");
		}
		else {
			System.out.println("The course does not exist!");	
		}
	}
		

	@Override
	public void viewStudentCourse(String firstName, String lastName) {
		List<String> studentNames=new ArrayList<String>();
		for( Student student : allStudent) {
			String fullname = student.getFirstName()+" "+student.getLastName();
			studentNames.add(fullname);
		}
		Integer ind = studentNames.indexOf(firstName+" "+lastName);
		List<String> courses = allStudent.get(ind).getCourses();
		System.out.println(courses.size()+" courses for "+ firstName +" "+lastName+":");
		for (String course:courses) {
			System.out.println(course);
		}
	}


	@Override
	public void exit() {
		System.out.println("You have been log out!");
		
	}


}
