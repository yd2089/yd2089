package HW1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main implements Serializable{

	private static final long serialVersionUID = 1L;
	public static String DIR = "/Users/dingyiling/Desktop/HW1/";
	public static void main(String[] args) throws IOException {
		ArrayList<Course> courseArray= new ArrayList<Course>();
//		ArrayList<Student> allStudent= new ArrayList<Student>();
		Scanner s = new Scanner (System.in);
		System.out.println("Is this your first time using this system? Please enter yes or no.");
		String answer=s.nextLine();
		if (answer.equals("yes")) {	
//			ArrayList<Course> courseArray=new ArrayList<Course>();
			//String choice="";
			BufferedReader BR = new BufferedReader(new FileReader(DIR+"MyUniversityCourses.csv"));
			String line = "";
			String firstline = BR.readLine();
			while((line=BR.readLine())!=null) {
				String[]info=line.split(",");
				Course course1=new Course(info[0],info[1],Integer.parseInt(info[2]),Integer.parseInt(info[3]),info[5],Integer.parseInt(info[6]),info[7]);
				courseArray.add(course1);

			}
			BR.close();
		}
		else if (answer.equals("no")) {
			try{
	            ObjectInputStream Sin = new ObjectInputStream(new FileInputStream("courseFile.ser"));
	            courseArray = (ArrayList<Course>) Sin.readObject();
	            Sin.close();
	 
	         }
			catch(Exception e){
	             System.out.println("Error!");
	             e.printStackTrace();
	             return;
	         }
			try{
	            ObjectInputStream Sin = new ObjectInputStream(new FileInputStream("studentFile.ser"));
	            User.allStudent = (ArrayList<Student>) Sin.readObject();
	            Sin.close();
	 
	         }
			catch(Exception e){
	             System.out.println("Error!");
	             e.printStackTrace();
	             return;
	         }
		}
//		File file=new File("course.ser");
		System.out.println("Please enter your username: ");
		String un=s.nextLine();
		System.out.println("Please enter your password: ");
		String pw=s.nextLine();
		
		// admin
		if (un.equals("Admin")&&pw.equals("Admin001")) {
			System.out.println("Please enter your firstname: ");
			String fn=s.nextLine();
			System.out.println("Please enter your lastname: ");
			String ln=s.nextLine();
			Admin admin1=new Admin(un,pw,fn,ln);
			System.out.println("Do you want to do? Please enter the serial number. \n 1.course management \n 2.report");
			String c=s.nextLine();
			if (c.equals("1")) {
				System.out.println("Please enter the serial number of what you want to do next \n"
						+ "1. Create a new course\n"
						+ "2. Delete a course\n"
						+ "3. Edit a course\n"
						+ "4. Display information for a given course\n"
						+ "5. Register a student\n"
						+ "6. Exit");
				String choice=s.nextLine();
				System.out.println(choice);
				if (choice.equals("1")) {
					System.out.println("Please enter the course name: ");
					String courseName=s.nextLine();
					System.out.println("Please enter the course ID: ");
					String courseID=s.nextLine();
					System.out.println("Please enter the maximun number of students: ");
					Integer maxStudent=Integer.parseInt(s.nextLine());
					System.out.println("Please enter the current Student: ");
					Integer currentStudent=Integer.parseInt(s.nextLine());
					System.out.println("Please enter the instructor name: ");
					String instructorName=s.nextLine();
					System.out.println("Please enter the section number: ");
					Integer sectionNumber=Integer.parseInt(s.nextLine());
					System.out.println("Please enter the location: ");
					String location=s.nextLine();
					Course nc=new Course(courseName,courseID,maxStudent,currentStudent,instructorName,sectionNumber,location);
					admin1.createCourse(nc, courseArray);
				}
				else if (choice.equals("2")) {
					System.out.println("Please enter the course name that you want to delete: ");
					String courseName=s.nextLine();
					System.out.println("Please enter its section number: ");
					Integer sectionNumber=Integer.parseInt(s.nextLine());
					Integer count=0;
					for (int i=0;i<courseArray.size();i++) {
						if (courseName.equals(courseArray.get(i).getCourseName())&&sectionNumber.equals(courseArray.get(i).getSectionNumber())) {
							Course deleteCourse=courseArray.get(i);
							admin1.DeleteCourse(deleteCourse,courseArray);
							count=0;
							break;
						}
						else {
							count=1;
						}
					}
					if(count!=0) {
						System.out.println("Course does not exist!");
					}
					
				}
				else if(choice.equals("3")) {
					System.out.println("Please enter the course name that you want to edit: ");
					String courseName=s.nextLine();
					System.out.println("Please enter its section number: ");
					Integer sectionNumber=Integer.parseInt(s.nextLine());
					Integer count=0;
					for (int i=0;i<courseArray.size();i++) {
						if (courseName.equals(courseArray.get(i).getCourseName())&&sectionNumber.equals(courseArray.get(i).getSectionNumber())) {
							Course editCourse=courseArray.get(i);
							admin1.editCourse(editCourse, courseArray);
							count=0;
							break;
						}
						else {
							count=1;
						}
					}
					if(count!=0) {
						System.out.println("The course named does not exist!");
					}
				}
				else if(choice.equals("4")) {
					System.out.println("Please enter the course name that you want to display: ");
					String courseName=s.nextLine();
					System.out.println("Please enter its section number: ");
					Integer sectionNumber=Integer.parseInt(s.nextLine());
					Integer count=0;
					for (int i=0;i<courseArray.size();i++) {
						if (courseName.equals(courseArray.get(i).getCourseName())&&sectionNumber.equals(courseArray.get(i).getSectionNumber())) {
							admin1.displayGivenCourse(courseName,sectionNumber, courseArray);
							count=0;
							break;
						}
						else {
							count=1;
						}
					}
					if(count!=0) {
						System.out.println("The course does not exist!");
					}
				}
				else if(choice.equals("5")) {
					System.out.println("Please enter the course name that you want to display: ");
					String courseName=s.nextLine();
					System.out.println("Please enter its section number: ");
					Integer sectionNumber=Integer.parseInt(s.nextLine());
					System.out.println("Please enter the student's firstname: ");
					String firstName=s.nextLine();
					System.out.println("Please enter the student's lastname: ");
					String lastName=s.nextLine();
					System.out.println("Please enter student's username: ");
					String username=s.nextLine();
					System.out.println("Please enter student's password: ");
					String password=s.nextLine();
					admin1.registerStudent(username, password, firstName, lastName, courseName, sectionNumber, courseArray);
				}
				else if (choice.equals("6")) {
					admin1.Exit();
				}
			}
			else if(c.equals("2")) {
				System.out.println("Please enter the serial number of the report you want to view:\n"
						+ "1. View all courses\n"
						+ "2. View all courses that are FULL\n"
						+ "3. Write to a file the list of course that are Full\n"
						+ "4. View the names of the students being registered in a specific course\n"
						+ "5. View the list of courses that a given student is being registered on \n"
						+ "6. Sort courses based on the current number of student registers\n"
						+ "7. Exit");
				String choice=s.nextLine();
				if (choice.equals("1")) {
					System.out.println("Here are all the courses: ");
					for(int i=0;i<courseArray.size();i++) {
						System.out.print("Course ID"+courseArray.get(i).getCourseID()+"\n"
									+"Course Name: "+courseArray.get(i).getCourseName()+"\n"
									+"Max Student: "+courseArray.get(i).getMaxStudent()+"\n"
									+"Current Student: "+courseArray.get(i).getCurrentStudent()+"\n"
									+"Course Instructors: "+courseArray.get(i).getInstructorName()+"\n"
									+"Course Location: "+courseArray.get(i).getLocation()+"\n");
					}
					
				}
				else if (choice.equals("2")) {
					System.out.println("Here are all the FULL courses: ");
					for(int i=0;i<courseArray.size();i++) {
						if (courseArray.get(i).getCurrentStudent()>=courseArray.get(i).getMaxStudent()) {
							System.out.print(courseArray.get(i).getCourseName()+ "\n");
						}
					}
				}
				else if (choice.equals("3")) {
					BufferedWriter BW = new BufferedWriter(new FileWriter(DIR+"fullClass"));
					for(int i=0;i<courseArray.size();i++) {
						if (courseArray.get(i).getCurrentStudent()>=courseArray.get(i).getMaxStudent()) {
							BW.write(courseArray.get(i).getCourseName()+ "\n");
						}
					}
					BW.close();
					System.out.println("The list of course that are Full has been written to a file! ");
				}
				else if (choice.equals("4")) {
					System.out.println("Please enter the course name you want to view: ");
					String courseName=s.nextLine();
					System.out.println("Please enter its section number:");
					Integer sectionNumber=s.nextInt();
					Integer count=0;
					for(int i=0;i<courseArray.size();i++) {
						if (sectionNumber.equals(courseArray.get(i).getSectionNumber())&&courseName.equals(courseArray.get(i).getCourseName())) {
							System.out.print("Course Name: "+courseArray.get(i).getCourseName()+"\n"
									+"Course ID: "+courseArray.get(i).getCourseID()+"\n"
									+"List of Names: "+courseArray.get(i).getStudentName()+"\n");
							count=0;
							break;
						}
						else {
							count=1;
						}
					}
					if (count!=0) {
						System.out.println("This course does not exist!");
					}
				}
				else if (choice.equals("5")) {
					System.out.println("Please enter student's firstname: ");
					String firstName=s.nextLine();
					System.out.println("Please enter student's lastname: ");
					String lastName=s.nextLine();
					Integer count=0;
					for(int i=0;i<User.allStudent.size();i++) {
						if((User.allStudent.get(i).getFirstName().equals(firstName))&&(User.allStudent.get(i).getLastName().equals(lastName))) {
							admin1.viewStudentCourse(firstName, lastName);
							count=0;
							break;
						}
						else {
							count=1;
						}
					}
					if(count!=0) {
						System.out.println("Error!");
					}
				}
				else if (choice.equals("6")) {
					ArrayList<Course> sortCourse=new ArrayList<Course>();
					Integer max=0;
					Integer index=0;
					for(int i=0;i<courseArray.size()-1;i++) {
						index=i;
						for(int j=i+1;j<courseArray.size();j++) {
							if(courseArray.get(j).getCurrentStudent()>courseArray.get(i).getCurrentStudent()) {
								max=courseArray.get(j).getCurrentStudent();
							}
						sortCourse.set(i, courseArray.get(index));
						}
					}
					System.out.println("Sorting courses based on the current number of student registers has finished!");
				}
				else if (choice.equals("7")) {
					System.out.println("You have been logged out!");
				}
				else {
					System.out.println("Error!");
				}
				
			}
			else {
				System.out.println("Error!");
			}
		}
			
		else { //student
			List<String> studentUserNames=new ArrayList<String>();
			for( Student student : User.allStudent) {
				studentUserNames.add(student.getUserName());
			}
			if (!studentUserNames.contains(un)) {
				System.out.println("Please enter your firstname: ");
				String fn=s.nextLine();
				System.out.println("Please enter your lastname: ");
				String ln=s.nextLine();
				List<String> emptyCourse = new ArrayList<String>();
				Student newstudent=new Student(un,pw,fn,ln,emptyCourse);
				User.allStudent.add(newstudent);
				studentUserNames.add(un);
			}
			else {
				Integer ind = studentUserNames.indexOf(un);
				String correctPassword = User.allStudent.get(ind).getPassword();
//				if (pw != correctPassword) {
//					System.out.println("Wrong Password, please try again. ");
//					System.out.println(pw);
//					System.out.println(correctPassword);
//					System.exit(0); 
//				}				
			}
			Integer i = studentUserNames.indexOf(un);
			Student student1 = User.allStudent.get(i);
			String fn = student1.getFirstName();
			String ln = student1.getLastName();
			System.out.println("Please enter the serial number of what you want to do next: \n"
					+ "1. View all courses\n"
					+ "2. View all courses that are not FULL\n"
					+ "3. Register on a course\n"
					+ "4. Withdraw from a course\n"
					+ "5. View all courses that the current student is being registered in \n"
					+ "6. Exit");
			String choice=s.nextLine();
			if (choice.equals("1")) {
				student1.viewAllCourses(courseArray);
			}
			else if (choice.equals("2")) {
				student1.viewNotFullCourses(courseArray);
			}
			else if (choice.equals("3")) {
				System.out.println("Please enter the course name you want to register: ");
				String courseName=s.nextLine();
				System.out.println("Please enter the section number you want to register: ");
				Integer sectionNumber=Integer.parseInt(s.nextLine());
				String fullname = fn+' '+ln;
				System.out.println("number of students: "+User.allStudent.size());
				student1.registerCourse(courseName,sectionNumber,fullname, courseArray);
			}
			else if (choice.equals("4")) {
				System.out.println("Please enter the course name you want to withdraw: ");
				String courseName=s.nextLine();
				System.out.println("Please enter the section number you want to withdraw: ");
				Integer sectionNumber=Integer.parseInt(s.nextLine());
				student1.withdrawCourse(fn+" "+ln,courseName,courseArray,sectionNumber);
			}
			else if (choice.equals("5")) {
				student1.viewStudentCourse(fn,ln);
			}
			else if (choice.equals("6")) {
				student1.exit();
			}
			else {
				System.out.println("Error!");
			}
			
		}
		try {
			ObjectOutputStream Sout=new ObjectOutputStream(new FileOutputStream("courseFile.ser"));
			Sout.writeObject(courseArray);
			Sout.flush();
			Sout.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
		try {
			ObjectOutputStream Sout=new ObjectOutputStream(new FileOutputStream("studentFile.ser"));
			Sout.writeObject(User.allStudent);
			Sout.flush();
			Sout.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
		
	}
}
