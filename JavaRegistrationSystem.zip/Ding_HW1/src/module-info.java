module Ding_HW1 {
}